# coding: utf8
# auto: flytrap
# from distutils.core import setup
from setuptools import setup, find_packages

NAME = 'custom'
VERSION = 0.1

setup(name=NAME,
      version=VERSION,

      author='flytrap',
      author_email='hiddes@126.com',
      url='https://github.com/hiddes/custom',
      description='Custom self carry',

      packages=find_packages()
      )
